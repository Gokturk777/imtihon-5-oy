function bahoBer(ball) {
    if (ball >= 86) {
    return "A'lo (5)";
        } else if (ball >= 71) {
    return "Yaxshi (4)";
        } else if (ball >= 56) {
    return "Qoniqarli (3)";
        } else {
    return "Qoniqarsiz (2)";
        }
}

function tahlilQilish(){
    let matn = document.getElementById("ballar").value;
    let qismlar = matn.split(",");

    let ballar = [];

    for (let i = 0; i < qismlar.length; i++){
    let ball = qismlar[i].trim();

    if (ball === "" || isNaN(ball)){
    document.getElementById("natija").innerHTML =
    "Xato! Faqat son kiriting.";
    return;
}

ball = Number(ball);

    if (ball < 0 || ball > 100){
    document.getElementById("natija").innerHTML =
    "Xato! Ball 0 dan 100 gacha bo'lishi kerak.";
    return;
}

ballar.push(ball);
    }

    let summa = 0;
    let engYuqori = ballar[0];
    let engPast = ballar[0];
    let otgan = 0;

    for (let i = 0; i < ballar.length; i++){
    summa = summa + ballar[i];

    if (ballar[i] > engYuqori){
    engYuqori = ballar[i];
}

    if (ballar[i] < engPast){
    engPast = ballar[i];
}

    if (ballar[i] >= 56){
    otgan++;
}

    }

    let ortacha = summa / ballar.length;
    ortacha = Math.round(ortacha * 10) / 10;

    let umumiyBaho = bahoBer(ortacha);

    document.getElementById("natija").innerHTML =
        "Fanlar soni: " + ballar.length + "<br>" +
        "O'rtacha ball: " + ortacha + "<br>" +
        "Eng yuqori: " + engYuqori + "<br>" +
        "Eng past: " + engPast + "<br>" +
        "O'tgan fanlar: " + otgan + " ta<br>" +
        "Umumiy baho: " + umumiyBaho;
}